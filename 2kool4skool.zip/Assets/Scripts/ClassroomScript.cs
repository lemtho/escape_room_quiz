﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClassroomScript : MonoBehaviour
{
    /* Declare and initialize public member variables (i.e., sibling, children game objects). */
    
    // public GameObject clock;
    // public GameObject computer;

    public GameObject godzilla;
    public GameObject SAQuestionPanel;

    public GameObject mainCamera;

    public GameObject ExperimentClassroom;
    public GameObject NorthWall;
    public GameObject EastWall;
    public GameObject SouthWall;
    public GameObject WestWall;

    private int showWall = 1; // 1 = North Wall, 2 = East Wall, 3 = South Wall, 4 = West Wall.

    /* Declare and initialize private member variables used inside the (parent) Canvas object. */
    private bool isZoomed = false;
    
    // Start is called before the first frame update
    void Start()
    {
        // Hide the Short Answer Question Panel.
        SAQuestionPanel.SetActive(false); 

        // Hide the ExperimentClassroom, East Wall, South Wall, and West Wall.
        ExperimentClassroom.SetActive(false);
        EastWall.SetActive(false);
        SouthWall.SetActive(false);
        WestWall.SetActive(false);
        NorthWall.SetActive(true);
        showWall = 1;
    }

    // Update is called once per frame
    void Update()
    {
        // On right arrow key press...
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            // IF North Wall was displayed, display East Wall.
            if (showWall == 1)
            {
                // Debug.Log("East Wall");
                NorthWall.SetActive(false); 
                EastWall.SetActive(true); 
                showWall = 2;
            }

            // ELSE IF East Wall was displayed, display South Wall.
            else if (showWall == 2)
            {
                // Debug.Log("South Wall");
                EastWall.SetActive(false); 
                SouthWall.SetActive(true); 
                showWall = 3;
            }

            // ELSE IF South Wall was displayed, display West Wall.
            else if (showWall == 3)
            {
                // Debug.Log("West Wall");
                SouthWall.SetActive(false); 
                WestWall.SetActive(true); 
                showWall = 4;
            }

            // ELSE IF West Wall was displayed, display North Wall.
            else if (showWall == 4)
            {
                // Debug.Log("North Wall");
                WestWall.SetActive(false); 
                NorthWall.SetActive(true); 
                showWall = 1;
            }
        }

        else if (Input.GetMouseButtonDown(1))
        {
            if (isZoomed == false)
            {
                mainCamera.GetComponent<Camera>().orthographicSize = 100;
                isZoomed = true;
            }

            else if (isZoomed == true)
            {
                mainCamera.GetComponent<Camera>().orthographicSize = 10.5371f;
                isZoomed = false;
            }
        }
        
        /* On left mouse click...
        SOURCE: Unity 2D: Detecting GameObject Clicks using Raycasts at 
        https://kylewbanks.com/blog/unity-2d-detecting-gameobject-clicks-using-raycasts 
        */
        if (Input.GetMouseButtonDown(0)) 
        {   
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);
            
            RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);

            // IF a game object is clicked...
            if (hit.collider != null) 
            {
                // TEST: Output to console the object that as clicked.
                // Debug.Log(hit.collider.gameObject.name + " was clicked!");

                // IF Godzilla on the North Wall was clicked...
                if (hit.collider.gameObject.name == godzilla.name)
                {
                    // Debug.Log(hit.collider.gameObject.name + " was clicked!");
                    
                    // IF Short Answer Question Panel is already inactive...
                    if (SAQuestionPanel.activeSelf == false)
                    {
                        // Short Answer Question Panel pops up.
                        SAQuestionPanel.SetActive(true);
                    }
                }

                // // ELSE IF computer was clicked...
                // else if (hit.collider.gameObject.name == computer.name)
                // {   
                //     // IF camera is at normal view...
                //     if (isZoomed == false)
                //     {
                //         // Zoom camera in.
                //         mainCamera.GetComponent<Camera>().orthographicSize = 10;
                //         Debug.Log(mainCamera.GetComponent<Camera>().orthographicSize);
                //         isZoomed = true;
                //     }

                //     // ELSE, camera is already zoomed in...
                //     else if (isZoomed == true)
                //     {
                //         // Reset camera view.
                //         mainCamera.GetComponent<Camera>().orthographicSize = 5;
                //         Debug.Log(mainCamera.GetComponent<Camera>().orthographicSize);
                //         isZoomed = false;
                //     }
                // }
            }

            else
            {
                // Hide or close the Short Answer Question Panel.
                SAQuestionPanel.SetActive(false);
            }
        }
    }
}
